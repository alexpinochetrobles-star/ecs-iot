#include <WiFi.h>
#include <PubSubClient.h>
#include <ModbusMaster.h>

const char* WIFI_SSID   = "TU_WIFI";
const char* WIFI_PASS   = "TU_PASS";
const char* MQTT_HOST   = "192.168.1.50";      // IP de la Raspberry Pi
const int   MQTT_PORT   = 1883;
const char* MQTT_USER   = "ecs";
const char* MQTT_PASS   = "tu_password";
const char* TOPIC       = "pozo/profundidad/lecturas";

WiFiClient   espClient;
PubSubClient client(espClient);
ModbusMaster sensor;

void setup() {
  Serial.begin(115200);

  WiFi.begin(WIFI_SSID, WIFI_PASS);
  while (WiFi.status() != WL_CONNECTED) { delay(500); Serial.print("."); }
  Serial.println("\nWiFi OK");

  Serial2.begin(9600, SERIAL_8N1, 16, 17);   // RS485: RX=16, TX=17
  sensor.begin(1, Serial2);

  client.setServer(MQTT_HOST, MQTT_PORT);
}

void loop() {
  if (!client.connected()) reconnect();
  client.loop();

  // Sensor de presión hidrostática: lectura en registro 0 (2 words)
  uint8_t r = sensor.readHoldingRegisters(0, 2);
  if (r == sensor.ku8MBSuccess) {
    uint32_t raw = (sensor.getResponseBuffer(0) << 16) | sensor.getResponseBuffer(1);
    float nivel_m = raw / 1000.0f;   // Ajustar según datasheet del sensor

    String payload = String("{\"nivel_m\":") + String(nivel_m, 2) +
                     ",\"nivel_estatico_m\":" + String(nivel_m, 2) +
                     ",\"nivel_dinamico_m\":" + String(nivel_m, 2) +
                     ",\"caudal_lps\":0}";
    client.publish(TOPIC, payload.c_str());
  } else {
    Serial.printf("Error Modbus: %d\n", r);
  }

  delay(5000);   // Cada 5 s
}

void reconnect() {
  while (!client.connected()) {
    if (client.connect("ESP32-Pozo", MQTT_USER, MQTT_PASS)) {
      Serial.println("MQTT OK");
    } else {
      Serial.printf("MQTT fallo rc=%d\n", client.state());
      delay(3000);
    }
  }
}