# AquaPozo IoT · Plataforma de monitoreo y control de pozo profundo

Plataforma web IoT en **Django** para monitorear y controlar un pozo profundo
en tiempo real, construida sobre el repositorio base
[`urbanatika/ecs-iot`](https://github.com/urbanatika/ecs-iot) del curso.

**Tópicos de Especialidad II: IoT** · Solemne 2 (tarea preparatoria)
**Integrantes:** Alexander Pinochet · Diego Hernández · Raúl Agüero
**Docente:** Diego Elorza

![Dashboard del pozo](docs/img/dashboard.png)

---

## Qué hace

| Equipo | Rol en el pozo | Variables de proceso |
|---|---|---|
| **ESP32** (boca del pozo) | Mide nivel (HC-SR04) y caudal (YF-S201), controla el relé de la bomba (modo AUTO/MANUAL) y la protege contra marcha en seco | `nivel_m`, `caudal_lpm`, `volumen_l`, `motor`, `modo_auto`, `falla_seco`, `rssi_dbm` |
| **Raspberry Pi** (tablero de control) | Corre la plataforma (Docker) y el controlador del tablero: flotador de nivel mínimo, paro de emergencia, baliza y horómetro de la bomba. Aplica el **enclavamiento** (paro / nivel mínimo ⇒ apaga la bomba) | `flotador_min_ok`, `paro_emergencia`, `baliza`, `horometro_h`, `cpu_temp_c` |

El dashboard muestra un **sinóptico animado del pozo** (nivel de agua, bomba,
caudal, estanque, tablero), KPIs, alarmas activas, botones de **mando**
(encender/apagar bomba, modo automático, baliza) y la **auditoría de
comandos** (qué usuario mandó qué y cuándo). Debajo están todas las variables
de cada equipo con su gráfico/LED/botón.

## Arquitectura

```mermaid
flowchart LR
  subgraph Pozo
    ESP[ESP32<br/>HC-SR04 · YF-S201 · relé bomba]
  end
  subgraph Tablero
    subgraph RPI[Raspberry Pi]
      GW[gateway.py<br/>flotador · paro · baliza · horómetro]
      subgraph Docker[docker compose]
        MQ[(Mosquitto<br/>MQTT)]
        L[mqtt_listener]
        DB[(PostgreSQL)]
        W[Django web<br/>dashboard]
      end
    end
  end
  ESP -- WiFi / MQTT --> MQ
  GW -- MQTT --> MQ
  MQ --> L --> DB --> W
  W -- comandos /set --> MQ
  MQ -- /set --> ESP
  MQ -- /set --> GW
  N[Navegador<br/>usuarios con login] --> W
```

**Contrato MQTT** (el mismo del repo base):

- Telemetría: `ecs/<equipo>/<variable>` → `{"value": 0.85, "timestamp": "...Z", "token": "<token>"}`
- Comandos: `ecs/<equipo>/<variable>/set` → `{"value": 1, "token": "<token>"}`

Cada equipo tiene su **token**; el listener rechaza (cuarentena) mensajes de
equipos no registrados o con token inválido.

## Estructura del repositorio

```
backend/                Django (app monitoring): modelos, vistas, dashboard
  monitoring/templates/monitoring/_pozo_panel.html   sinóptico del pozo
  monitoring/static/monitoring/js/pozo.js            animación, alarmas y mando
  monitoring/management/commands/setup_pozo.py       crea equipos y variables del pozo
firmware/esp32_pozo/    firmware de la ESP32 (Arduino)
raspberry/              controlador del tablero en la Raspberry (GPIO, horómetro, enclavamiento)
simulator/              simulador del pozo completo (para pruebas / respaldo en la demo)
mosquitto/              configuración del broker MQTT
docs/                   documentación del repo base del profesor
```

---

## Puesta en marcha

### 0. Tener el repositorio en la cuenta personal (rúbrica 1)

En GitHub: **Fork** de `urbanatika/ecs-iot` a la cuenta personal (o crear un
repo vacío) y subir este código ahí. Luego, en la Raspberry Pi:

```bash
git clone https://github.com/<tu-usuario>/ecs-iot.git
cd ecs-iot
```

### 1. Servidor (Raspberry Pi con Docker)

Se recomienda Raspberry Pi OS de 64 bits. Instalar Docker una vez:

```bash
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER     # cerrar sesión y volver a entrar
```

Configurar el `.env`:

```bash
cp .env.example .env
nano .env
```

- Cambia todas las contraseñas (`POSTGRES_PASSWORD`, `MQTT_PASSWORD`,
  `DJANGO_SUPERUSER_PASSWORD`, `DJANGO_SECRET_KEY`).
- En `DJANGO_ALLOWED_HOSTS` agrega la IP de la Raspberry (ej. `localhost,127.0.0.1,192.168.1.50`).
- Genera los 2 tokens de los equipos y pégalos en `POZO_TOKEN_ESP32` y `POZO_TOKEN_RPI`:

  ```bash
  python3 -c "import secrets;[print(secrets.token_urlsafe(32)) for _ in range(2)]"
  ```

Crear la clave del broker MQTT (una sola vez, mismo usuario/clave del `.env`):

```bash
docker run --rm -v "$PWD/mosquitto/config:/mosquitto/config" eclipse-mosquitto:2 \
  sh -c "mosquitto_passwd -b -c /mosquitto/config/passwd ecs TU_MQTT_PASSWORD && chmod 644 /mosquitto/config/passwd"
```

Levantar todo:

```bash
docker compose up -d --build
```

Al arrancar se aplican las migraciones, se crea el superusuario y
`setup_pozo` registra automáticamente los 2 equipos con sus variables y
widgets. Entra a `http://<IP-de-la-raspberry>:8000/` con el usuario del `.env`.

> Para ver o regenerar tokens: menú **Dispositivos**. Para re-ejecutar la
> configuración: `docker compose exec web python manage.py setup_pozo`.

### 2. ESP32 (firmware)

1. Arduino IDE → instalar la placa **esp32** (Espressif) y las librerías
   **PubSubClient** y **ArduinoJson** (6.x o 7.x).
2. Abrir `firmware/esp32_pozo/esp32_pozo.ino`.
3. Copiar `config.example.h` como `config.h` y completar WiFi, IP de la
   Raspberry, usuario/clave MQTT y `DEVICE_TOKEN` (= `POZO_TOKEN_ESP32`).
4. Placa **ESP32 Dev Module** → Subir. En el Monitor Serie (115200) se ve la
   telemetría que se publica.

Conexiones (las mismas del proyecto):

| Componente | Pin ESP32 | Nota |
|---|---|---|
| HC-SR04 TRIG | GPIO 5 | VCC a 5 V |
| HC-SR04 ECHO | GPIO 18 | **divisor de tensión** 5 V → 3,3 V (ej. 1 kΩ / 2 kΩ) |
| YF-S201 señal (amarillo) | GPIO 27 | rojo a 5 V, negro a GND; divisor si la señal sale a 5 V |
| Relé de la bomba (IN) | GPIO 26 | relé activo en bajo (configurable en `config.h`) |

> **Lógica del modo AUTO.** El sketch original encendía la bomba con nivel
> **bajo** y la apagaba con nivel **alto** (lógica de *llenar un estanque*).
> Si el ultrasonido mide el **pozo**, eso es al revés: la bomba arrancaría con
> el pozo vacío y saltaría la falla de marcha en seco. Por eso
> `config.h` trae `LOGICA_POZO 1` (arranca con nivel alto, para con nivel bajo).
> Si el sensor mide el estanque que se llena, usar `LOGICA_POZO 0`.

### 3. Raspberry Pi: controlador del tablero

```bash
cd raspberry
python3 -m venv --system-site-packages .venv      # --system-site-packages para usar gpiozero del sistema
.venv/bin/pip install -r requirements.txt
cp config.example.env config.env
nano config.env      # tokens y pines
.venv/bin/python gateway.py
```

Para que arranque solo al encender la Raspberry:

```bash
sudo cp aquapozo-gateway.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now aquapozo-gateway
journalctl -u aquapozo-gateway -f
```

Conexiones del tablero (numeración BCM, configurable en `config.env`):

| Elemento | GPIO | Conexión |
|---|---|---|
| Flotador de nivel mínimo (NC) | 17 | entre GPIO17 y GND (pull-up interno) |
| Paro de emergencia (NC) | 22 | entre GPIO22 y GND; si se presiona **o se corta el cable** ⇒ paro |
| Baliza / luz de alarma | 27 | módulo relé (IN=GPIO27, VCC=5 V, GND) |

**Enclavamiento:** si se activa el paro de emergencia o el flotador marca
nivel mínimo, la Raspberry ordena a la ESP32 apagar la bomba (`motor/set = 0`)
y enciende la baliza. Para volver a operar: quitar la causa y presionar
**Modo automático** en el dashboard.

**Horómetro:** la Raspberry escucha el estado de la bomba que publica la ESP32
y acumula las horas de marcha en `horometro.json` (se mantiene aunque se
reinicie).

### 4. Usuarios y control de acceso (rúbrica 4)

- Login obligatorio; usuarios guardados en **PostgreSQL**.
- Roles: **Global** (ve y controla todo), **Administrador** (gestiona
  usuarios) y **Operador** (solo sus equipos). Se administran en
  **Configuración → Usuarios**.
- Cada comando a un actuador queda registrado con usuario y hora (panel
  *Últimos comandos* y en `/admin/` → Registro de comandos).
- Para que un operador vea el pozo: `docker compose exec web python manage.py setup_pozo --owner <usuario>`.

---

## Probar sin hardware (simuladores)

- **Pozo completo** (ESP32 + Raspberry simuladas, responden a los botones):

  ```bash
  docker compose --profile simulador up -d
  ```

  Con `SIM_EQUIPOS` en el `.env` se eligen solo los equipos que falten
  (ej. `SIM_EQUIPOS=esp32` si solo falta la ESP32). **No simular un equipo que esté conectado de verdad.**

- **Tablero sin GPIO** (en un PC): `python3 gateway.py --simular-gpio`; el paro
  y el flotador se fuerzan editando `sim_gpio.json`.

- **Sin Docker** (desarrollo en un PC): `DB_ENGINE=sqlite` en el `.env`, luego
  `python manage.py migrate`, `createsuperuser`, `setup_pozo`, `runserver` y
  `run_mqtt_listener` (necesita un broker MQTT local).

## Guion para la demostración (rúbrica 5)

1. Iniciar sesión → los 2 equipos aparecen **en línea** (ESP32 y Raspberry Pi).
2. Mover agua / tapar el sensor: el **nivel** del sinóptico y el gráfico cambian en vivo.
3. **Encender bomba** → la ESP32 activa el relé, sube el caudal (YF-S201) y el
   horómetro empieza a contar. **Apagar bomba** → el caudal vuelve a cero.
4. Encender la bomba **sin agua** (o tapando el paso) → sin caudal → a los 10 s la
   ESP32 corta por **marcha en seco** (alarma roja). **Modo automático** para rearmar.
5. Presionar el **paro de emergencia** del tablero → la bomba se detiene sola y se enciende la baliza.
6. Mostrar **Últimos comandos** (quién hizo cada acción) y el control de usuarios.

## Solución de problemas

| Síntoma | Causa probable |
|---|---|
| Equipo "sin datos" | token o slug distinto entre el equipo y la plataforma (ver Admin → *Unregistered readings*) |
| La ESP32 no conecta al broker | IP de la Raspberry, puerto, usuario/clave MQTT; el PC/Raspberry debe estar en la misma red |
| `DisallowedHost` al entrar por IP | falta la IP en `DJANGO_ALLOWED_HOSTS` del `.env` |
| Botón sin efecto | el equipo debe estar en línea; ver log de la ESP32 (Monitor Serie) o `journalctl -u aquapozo-gateway` |

---

Basado en la plataforma ECS IoT del profesor (ver
[`docs/PLATAFORMA_BASE.md`](docs/PLATAFORMA_BASE.md) para la documentación
original: roles, mapa, despliegue en Railway, etc.).
