"""Deja la plataforma lista para el pozo profundo (AquaPozo IoT).

Crea (o actualiza, se puede correr las veces que quieras):
  - el tipo de producto "Pozo profundo" y el producto "Pozo 001",
  - los 2 equipos: ESP32 (sensores y bomba) y Raspberry Pi (tablero de control),
  - sus variables de proceso con la unidad y el widget adecuado (gráfico, LED, botón...).

Uso:
    python manage.py setup_pozo                      # dueño = superusuario
    python manage.py setup_pozo --owner admin --env-file tokens_pozo.env

Tokens: si en el entorno existen POZO_TOKEN_ESP32 / POZO_TOKEN_RPI
se usan esos (así no hay que volver a programar la ESP32 si se borra la BD).
Si no existen, se conserva el token actual o se genera uno nuevo, y se imprime.
"""
import os

from django.conf import settings
from django.contrib.auth.models import User
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from monitoring.models import Device, Product, ProductType, Sensor, Widget

# (variable, unidad, tipo de widget, opciones del widget)
ESP32_SENSORS = [
    ("nivel_m", "m", Widget.TYPE_LINE_CHART, {"min_value": 0, "max_value": 1.2}),
    ("caudal_lpm", "L/min", Widget.TYPE_LINE_CHART, {}),
    ("volumen_l", "L", Widget.TYPE_NUMERIC, {}),
    ("motor", "", Widget.TYPE_BUTTON, {"button_on_value": 1, "button_off_value": 0}),
    ("modo_auto", "", Widget.TYPE_BUTTON, {"button_on_value": 1, "button_off_value": 0}),
    ("falla_seco", "", Widget.TYPE_LED, {"led_on_threshold": 1}),
    ("rssi_dbm", "dBm", Widget.TYPE_NUMERIC, {}),
]

RPI_SENSORS = [
    ("flotador_min_ok", "", Widget.TYPE_LED, {"led_on_threshold": 1}),
    ("paro_emergencia", "", Widget.TYPE_LED, {"led_on_threshold": 1}),
    ("baliza", "", Widget.TYPE_BUTTON, {"button_on_value": 1, "button_off_value": 0}),
    ("horometro_h", "h", Widget.TYPE_NUMERIC, {}),
    ("cpu_temp_c", "°C", Widget.TYPE_METER, {"min_value": 30, "max_value": 85}),
]

# Ubicación de referencia del pozo (cámbiala por la real).
POZO_LAT, POZO_LNG = -38.7359, -72.5904


class Command(BaseCommand):
    help = "Crea/actualiza los equipos y variables del pozo profundo (ESP32 y Raspberry Pi)."

    def add_arguments(self, parser):
        parser.add_argument("--owner", help="Usuario dueño de los equipos (por defecto, el primer superusuario).")
        parser.add_argument("--env-file", help="Escribe los tokens en este archivo (formato CLAVE=valor).")

    @transaction.atomic
    def handle(self, *args, **opts):
        owner = self._owner(opts.get("owner"))

        ptype, _ = ProductType.objects.get_or_create(slug="pozo-profundo", defaults={"name": "Pozo profundo"})
        product, _ = Product.objects.get_or_create(
            owner=owner,
            name="Pozo 001",
            defaults={"product_type": ptype, "latitude": POZO_LAT, "longitude": POZO_LNG},
        )

        # El proyecto ya no usa PLC: si quedó de una versión anterior, se desactiva.
        Device.objects.filter(slug="plc-pozo-001").update(is_active=False)

        equipos = [
            ("ESP32", settings.POZO_ESP32_SLUG, "ESP32 · Sensores del pozo", "Boca del pozo", ESP32_SENSORS),
            ("RPI", settings.POZO_RPI_SLUG, "Raspberry Pi · Tablero", "Sala de tablero", RPI_SENSORS),
        ]

        lines = []
        for key, slug, name, location, sensors in equipos:
            device, created = Device.objects.get_or_create(
                slug=slug,
                defaults={
                    "owner": owner,
                    "product": product,
                    "name": name,
                    "location": location,
                    "latitude": POZO_LAT,
                    "longitude": POZO_LNG,
                },
            )
            env_token = os.environ.get(f"POZO_TOKEN_{key}", "").strip()
            if env_token and env_token != device.auth_token:
                device.auth_token = env_token
                device.save(update_fields=["auth_token"])

            for variable, unit, widget_type, widget_opts in sensors:
                sensor, _ = Sensor.objects.get_or_create(device=device, variable=variable, defaults={"unit": unit})
                if unit and sensor.unit != unit:
                    sensor.unit = unit
                    sensor.save(update_fields=["unit"])
                widget = sensor.get_widget()
                widget.widget_type = widget_type
                for field, value in widget_opts.items():
                    setattr(widget, field, value)
                widget.save()

            self.stdout.write(self.style.SUCCESS(f"{'Creado' if created else 'Actualizado'}: {name} ({slug})"))
            lines.append(f"POZO_TOKEN_{key}={device.auth_token}")

        self.stdout.write("\nTokens de los equipos (cópialos al firmware / scripts y a tu .env):")
        for line in lines:
            self.stdout.write(f"  {line}")

        if opts.get("env_file"):
            with open(opts["env_file"], "w", encoding="utf-8") as fh:
                fh.write("\n".join(lines) + "\n")
            self.stdout.write(f"\nGuardados en {opts['env_file']}")

    def _owner(self, username):
        if username:
            try:
                return User.objects.get(username=username)
            except User.DoesNotExist as exc:
                raise CommandError(f"No existe el usuario «{username}».") from exc
        owner = User.objects.filter(is_superuser=True).order_by("id").first()
        if owner is None:
            raise CommandError("No hay superusuario. Crea uno (createsuperuser) o usa --owner.")
        return owner
