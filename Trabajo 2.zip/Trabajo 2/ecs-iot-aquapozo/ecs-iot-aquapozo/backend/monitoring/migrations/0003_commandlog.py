import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ("monitoring", "0002_seed_product_types"),
    ]

    operations = [
        migrations.CreateModel(
            name="CommandLog",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("variable", models.CharField(max_length=50)),
                ("value", models.FloatField()),
                ("published", models.BooleanField(default=True, help_text="False si el broker MQTT no estaba disponible.")),
                ("created_at", models.DateTimeField(auto_now_add=True, db_index=True)),
                ("device", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="command_logs", to="monitoring.device")),
                ("user", models.ForeignKey(null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="command_logs", to=settings.AUTH_USER_MODEL)),
            ],
            options={
                "verbose_name": "Registro de comando",
                "verbose_name_plural": "Registro de comandos",
                "ordering": ["-created_at"],
            },
        ),
    ]
