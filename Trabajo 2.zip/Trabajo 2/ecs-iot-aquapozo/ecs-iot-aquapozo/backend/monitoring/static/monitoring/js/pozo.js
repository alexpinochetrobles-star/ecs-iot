// Sinóptico del pozo: escucha las lecturas que ya trae dashboard.js (evento "iot:data")
// y anima el esquema, los KPIs, las alarmas y los botones de mando.
(function () {
  const panel = document.getElementById("pozo-panel");
  if (!panel) return;

  const SLUG = { esp32: panel.dataset.esp32, rpi: panel.dataset.rpi };
  const NIVEL_MAX = parseFloat(panel.dataset.nivelMax) || 1.2;
  const ONLINE_SECONDS = 20;
  const CTL = {
    motor: panel.dataset.ctlMotor,
    modo: panel.dataset.ctlModo,
    baliza: panel.dataset.ctlBaliza,
  };

  let last = {}; // "slug/variable" -> valor
  const $ = (sel) => panel.querySelector(sel);
  const num = (v, d = 1) => (v === undefined || v === null ? "--" : Number(v).toFixed(d));
  const val = (dev, variable) => last[`${SLUG[dev]}/${variable}`];
  const isOn = (v) => v !== undefined && v !== null && v >= 0.5;

  function setKpi(name, text, foot) {
    const el = $(`[data-kpi="${name}"] b`);
    if (el) el.textContent = text;
    if (foot !== undefined) {
      const f = $(`[data-kpi="${name}"] [data-role="lps"]`);
      if (f) f.textContent = foot;
    }
  }

  function setChip(name, text, state) {
    const chip = $(`[data-chip="${name}"]`);
    if (!chip) return;
    chip.querySelector("b").textContent = text;
    chip.className = `chip ${state || ""}`;
  }

  function fill(id, color) {
    const el = panel.querySelector(`#${id}`);
    if (el) el.style.fill = color;
  }

  const C = {
    good: "var(--status-good)",
    warn: "var(--status-warn)",
    bad: "var(--status-critical)",
    off: "var(--text-muted)",
  };

  function render(data) {
    last = {};
    data.sensors.forEach((s) => {
      if (s.value !== null) last[`${s.device_slug}/${s.variable}`] = s.value;
    });

    // --- equipos en línea ---
    const serverNow = new Date(data.server_time).getTime();
    const online = {};
    Object.entries(SLUG).forEach(([key, slug]) => {
      const dev = data.devices.find((d) => d.slug === slug);
      const badge = $(`[data-equipo="${key}"]`);
      if (!dev || !dev.last_seen_at) {
        online[key] = false;
        if (badge) badge.className = "badge";
        return;
      }
      const age = (serverNow - new Date(dev.last_seen_at).getTime()) / 1000;
      online[key] = age <= ONLINE_SECONDS;
      if (badge) badge.className = `badge ${online[key] ? "online" : "offline"}`;
    });

    // --- ESP32: nivel, caudal, volumen, bomba ---
    const nivel = val("esp32", "nivel_m");
    const caudal = val("esp32", "caudal_lpm");
    const volumen = val("esp32", "volumen_l");
    const motor = val("esp32", "motor");
    const auto = val("esp32", "modo_auto");
    const seco = val("esp32", "falla_seco");

    const pct = nivel === undefined ? 0 : Math.max(0, Math.min(1, nivel / NIVEL_MAX));
    const top = 410 - pct * 260;
    const water = panel.querySelector("#pz-water");
    water.setAttribute("y", top);
    water.setAttribute("height", Math.max(0, 416 - top));
    panel.querySelector("#pz-water-top").setAttribute("y", top);
    panel.querySelector("#pz-nivel-txt").textContent = `${num(nivel, 2)} m`;
    const tagY = Math.max(130, Math.min(362, top));
    panel.querySelector("#pz-nivel-tag").setAttribute("transform", `translate(0 ${tagY})`);
    $('[data-kpi="nivel"] .kpi-bar-fill').style.width = `${pct * 100}%`;
    setKpi("nivel", num(nivel, 2));
    $('[data-kpi="nivel"] [data-role="pct"]').textContent =
      nivel === undefined ? "--% del rango del sensor" : `${Math.round(pct * 100)}% del rango del sensor`;
    setKpi("caudal", num(caudal, 1), caudal === undefined ? "-- L/s" : `${(caudal / 60).toFixed(3)} L/s`);
    setKpi("volumen", volumen === undefined ? "--" : (volumen / 1000).toFixed(3));

    const running = isOn(motor);
    const flowing = running && caudal > 0.5;
    panel.querySelector("#pz-impeller").classList.toggle("running", running);
    panel.querySelector("#pz-pipe-flow").classList.toggle("flowing", flowing);
    panel.querySelector("#pz-sonar").classList.toggle("active", !!online.esp32);
    panel.querySelector("#pz-motor-txt").textContent = motor === undefined ? "--" : running ? "EN MARCHA" : "DETENIDA";
    panel.querySelector("#pz-caudal-txt").textContent = `${num(caudal, 1)} L/min`;
    const tank = panel.querySelector("#pz-tank-water");
    const tankH = flowing ? 40 : 21;
    tank.setAttribute("height", tankH);
    tank.setAttribute("y", 83 - tankH);

    setChip("motor", motor === undefined ? "--" : running ? "En marcha" : "Detenida", motor === undefined ? "" : running ? "ok" : "off");
    setChip("modo", auto === undefined ? "--" : isOn(auto) ? "Automático" : "Manual", auto === undefined ? "" : isOn(auto) ? "ok" : "warn");
    setChip("seco", seco === undefined ? "--" : isOn(seco) ? "FALLA" : "Normal", seco === undefined ? "" : isOn(seco) ? "alarm" : "ok");

    // --- Raspberry Pi: tablero ---
    const flot = val("rpi", "flotador_min_ok");
    const paro = val("rpi", "paro_emergencia");
    const baliza = val("rpi", "baliza");
    fill("pz-float", flot === undefined ? C.off : isOn(flot) ? C.good : C.bad);
    fill("pz-led-paro", paro === undefined ? C.off : isOn(paro) ? C.bad : C.good);
    fill("pz-led-baliza", baliza === undefined ? C.off : isOn(baliza) ? C.warn : C.off);
    setChip("flotador", flot === undefined ? "--" : isOn(flot) ? "OK" : "BAJO", flot === undefined ? "" : isOn(flot) ? "ok" : "alarm");
    setChip("paro", paro === undefined ? "--" : isOn(paro) ? "ACTIVO" : "Normal", paro === undefined ? "" : isOn(paro) ? "alarm" : "ok");

    // --- Raspberry Pi: horómetro, CPU; ESP32: señal WiFi ---
    const horas = val("rpi", "horometro_h");
    const cpu = val("rpi", "cpu_temp_c");
    const rssi = val("esp32", "rssi_dbm");
    setKpi("horometro", num(horas, 2));
    setKpi("cpu", num(cpu, 1));
    setKpi("rssi", num(rssi, 0));
    const q = $('[data-kpi="rssi"] [data-role="rssi-q"]');
    q.textContent = rssi === undefined ? "--" : rssi >= -60 ? "buena" : rssi >= -75 ? "regular" : "débil";
    fill("pz-led-flotador", flot === undefined ? C.off : isOn(flot) ? C.good : C.bad);
    setChip("baliza", baliza === undefined ? "--" : isOn(baliza) ? "Encendida" : "Apagada", baliza === undefined ? "" : isOn(baliza) ? "warn" : "off");

    // --- alarmas activas ---
    const alarms = [];
    if (isOn(seco)) alarms.push("Marcha en seco: la ESP32 detuvo la bomba por falta de caudal. Revise el pozo y presione «Modo automático» para rearmar.");
    if (isOn(paro)) alarms.push("Paro de emergencia activo en el tablero: la bomba queda bloqueada.");
    if (flot !== undefined && !isOn(flot)) alarms.push("Flotador de nivel mínimo: agua bajo el mínimo, se protege la bomba.");
    Object.entries(online).forEach(([key, ok]) => {
      const names = { esp32: "ESP32", rpi: "Raspberry Pi" };
      const dev = data.devices.find((d) => d.slug === SLUG[key]);
      if (dev && dev.last_seen_at && !ok) alarms.push(`Sin señal de ${names[key]} (más de ${ONLINE_SECONDS} s sin datos).`);
    });
    const box = panel.querySelector("#pz-alarms");
    box.innerHTML = "";
    alarms.forEach((txt) => {
      const div = document.createElement("div");
      div.className = "pz-alarm";
      div.textContent = txt;
      box.appendChild(div);
    });
  }

  // --- mando ---
  const msg = panel.querySelector("#pz-ctl-msg");

  function addLogRow(equipo, variable, value) {
    const tbody = panel.querySelector(".pozo-log tbody");
    const empty = tbody.querySelector(".muted");
    if (empty) empty.parentElement.remove();
    const user = (document.querySelector(".topbar .user") || {}).textContent || "tú";
    const tr = document.createElement("tr");
    const now = new Date();
    const p2 = (n) => String(n).padStart(2, "0");
    const hora = `${p2(now.getDate())}-${p2(now.getMonth() + 1)} ${p2(now.getHours())}:${p2(now.getMinutes())}:${p2(now.getSeconds())}`;
    [hora, user, equipo, variable, value.toFixed(1)].forEach((t) => {
      const td = document.createElement("td");
      td.textContent = t;
      tr.appendChild(td);
    });
    tbody.prepend(tr);
    while (tbody.children.length > 8) tbody.lastElementChild.remove();
  }

  async function send(sensorId, value, equipo, variable, label) {
    if (!sensorId) {
      msg.textContent = `La variable «${variable}» aún no existe: el equipo debe publicarla al menos una vez y su widget debe ser de tipo Botón.`;
      msg.className = "ctl-msg error";
      return;
    }
    msg.textContent = `Enviando: ${label}…`;
    msg.className = "ctl-msg";
    const ok = await window.iotPostCommand(sensorId, value);
    msg.textContent = ok ? `Comando enviado: ${label}. Esperando confirmación del equipo…` : `No se pudo enviar «${label}».`;
    msg.className = ok ? "ctl-msg" : "ctl-msg error";
    if (ok) addLogRow(equipo, variable, value);
  }

  panel.querySelectorAll("[data-ctl]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const action = btn.dataset.ctl;
      if (action === "motor-on") send(CTL.motor, 1, "ESP32", "motor", "encender bomba");
      if (action === "motor-off") send(CTL.motor, 0, "ESP32", "motor", "apagar bomba");
      if (action === "auto") send(CTL.modo, 1, "ESP32", "modo_auto", "modo automático");
      if (action === "baliza") {
        const target = isOn(val("rpi", "baliza")) ? 0 : 1;
        send(CTL.baliza, target, "Raspberry Pi", "baliza", target ? "encender baliza" : "apagar baliza");
      }
    });
  });

  document.addEventListener("iot:data", (e) => render(e.detail));
})();
