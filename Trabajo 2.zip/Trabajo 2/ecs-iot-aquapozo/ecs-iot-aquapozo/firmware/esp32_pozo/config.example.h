// Copia este archivo como "config.h" (misma carpeta) y completa tus datos.
// config.h NO se sube a git (tiene el token y las claves), ver .gitignore.
#pragma once

// ---------------- Identidad del equipo en la plataforma ----------------
// La entrega "python manage.py setup_pozo" (o Dispositivos -> ver token).
#define DEVICE_SLUG   "esp32-pozo-001"
#define DEVICE_TOKEN  "pega-aqui-POZO_TOKEN_ESP32"

// ---------------- WiFi ----------------
#define WIFI_SSID     "TU_RED_WIFI"
#define WIFI_PASSWORD "TU_PASSWORD_WIFI"

// ---------------- Broker MQTT (Mosquitto de la plataforma) ----------------
// IP de la Raspberry Pi (o del PC) donde corre docker compose. NO uses "localhost".
#define MQTT_HOST     "192.168.1.50"
#define MQTT_PORT     1883                  // MOSQUITTO_HOST_PORT del .env
#define MQTT_USER     "ecs"                 // MQTT_USERNAME del .env
#define MQTT_PASS     "cambia-esta-clave"   // MQTT_PASSWORD del .env
#define MQTT_PREFIX   "ecs"                 // MQTT_TOPIC_PREFIX del .env

// ---------------- Pines (los mismos del proyecto original) ----------------
#define TRIG_PIN   5    // HC-SR04 TRIG
#define ECHO_PIN   18   // HC-SR04 ECHO (usar divisor 5V->3.3V)
#define RELAY_PIN  26   // relé de la bomba
#define FLOW_PIN   27   // YF-S201 señal
#define RELAY_ON   LOW  // relé activo en bajo (cambiar si el tuyo es activo en alto)
#define RELAY_OFF  HIGH

// ---------------- Calibración del nivel (cm medidos por el ultrasonido) ----------------
#define DISTANCIA_POZO_VACIO 150.0f   // distancia sensor -> agua con el pozo vacío
#define DISTANCIA_POZO_LLENO  30.0f   // distancia sensor -> agua con el pozo lleno

// Lógica del modo AUTO:
//   1 = POZO  : la bomba extrae DEL pozo medido -> arranca con nivel alto y para con nivel bajo
//               (protege la bomba; es lo que corresponde si el HC-SR04 mide el pozo).
//   0 = ESTANQUE: la bomba LLENA el estanque medido -> arranca con nivel bajo y para lleno
//               (lógica del sketch original control_nivel_pozo_mqtt).
#define LOGICA_POZO 1

// ---------------- Sensor de flujo YF-S201 ----------------
#define PULSOS_POR_LITRO      450.0f  // 7.5 Hz por L/min (datasheet) -> calibrar
#define UMBRAL_SIN_FLUJO_LPM  0.5f    // bajo esto se considera "sin flujo"
#define TIEMPO_MAX_SIN_FLUJO_MS 10000 // 10 s sin flujo con bomba encendida -> falla marcha en seco

// ---------------- Telemetría ----------------
#define PUBLICAR_CADA_MS 3000
