/*
  =====================================================================
  AquaPozo IoT · ESP32 de la boca del pozo
  Control de nivel de pozo profundo (HC-SR04 + YF-S201 + relé de bomba)
  =====================================================================
  Es el sketch "control_nivel_pozo_mqtt" del grupo, adaptado al contrato MQTT
  de la plataforma Django (repo ecs-iot). Se mantiene la misma lógica:
  lectura de nivel por ultrasonido, caudal y volumen por el YF-S201,
  modos AUTO / MANUAL y protección contra marcha en seco.

  Contrato MQTT de la plataforma:
    Publica   <prefijo>/<slug>/<variable>      {"value":..,"timestamp":..,"token":..}
    Escucha   <prefijo>/<slug>/<variable>/set  {"value":..,"token":..}

  Variables que publica (aparecen solas en el dashboard):
    nivel_m, caudal_lpm, volumen_l, motor (0/1), modo_auto (0/1),
    falla_seco (0/1), rssi_dbm
  Comandos que acepta:
    motor/set      1 = encender (MANUAL_ON) · 0 = apagar (MANUAL_OFF)
    modo_auto/set  1 = modo AUTO (y rearma la falla de marcha en seco)
                   0 = pasa a manual manteniendo el estado actual de la bomba

  Librerías (Arduino IDE -> Administrar bibliotecas):
    - PubSubClient (Nick O'Leary)
    - ArduinoJson  (Benoit Blanchon) versión 6.x
  Placa: "ESP32 Dev Module" (core esp32 de Espressif 2.x o 3.x).

  Antes de compilar: copia config.example.h como config.h y complétalo.
  =====================================================================
*/

#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <Preferences.h>
#include <time.h>

#include "config.h"

WiFiClient espClient;
PubSubClient mqtt(espClient);
Preferences prefs;

// ---------------------- ESTADO ----------------------
enum ModoOperacion { AUTO, MANUAL_ON, MANUAL_OFF };
ModoOperacion modo = AUTO;
bool motorEncendido = false;
bool fallaPorSeco = false;
bool ultrasonicoOk = true;

// niveles de arranque/parada en distancia (cm) medidos por el ultrasonido
const float DIST_NIVEL_BAJO = DISTANCIA_POZO_VACIO - 10.0f;  // agua cerca del fondo
const float DIST_NIVEL_ALTO = DISTANCIA_POZO_LLENO + 10.0f;  // agua cerca del sensor

float distanciaActual = -1;
unsigned long ultimaLecturaUltrasonico = 0;

volatile unsigned long pulsosTotales = 0;
unsigned long pulsosUltimoCiclo = 0;
unsigned long ultimoCalculoFlujo = 0;
float caudalLmin = 0;
double volumenTotalL = 0;
double volumenGuardado = 0;
unsigned long tiempoInicioSinFlujo = 0;

unsigned long ultimoEnvio = 0;
bool publicarYa = false;   // fuerza publicación inmediata tras un cambio de estado

char topicComandos[96];

void IRAM_ATTR contarPulso() { pulsosTotales++; }

// =====================================================================
//  WIFI
// =====================================================================
void conectarWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;
  Serial.print("Conectando a WiFi ");
  Serial.print(WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  unsigned long inicio = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - inicio < 15000) {
    delay(300);
    Serial.print(".");
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.print(" OK, IP: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println(" sin conexión (se reintentará).");
  }
}

// =====================================================================
//  MQTT (contrato de la plataforma)
// =====================================================================
bool horaSincronizada() { return time(nullptr) > 1700000000; }

void publicarVariable(const char* variable, float valor) {
  StaticJsonDocument<192> doc;
  doc["value"] = valor;
  if (horaSincronizada()) {
    char ts[25];
    time_t ahora = time(nullptr);
    strftime(ts, sizeof(ts), "%Y-%m-%dT%H:%M:%SZ", gmtime(&ahora));  // UTC
    doc["timestamp"] = ts;
  }
  doc["token"] = DEVICE_TOKEN;

  char payload[192];
  size_t n = serializeJson(doc, payload);
  char topic[96];
  snprintf(topic, sizeof(topic), "%s/%s/%s", MQTT_PREFIX, DEVICE_SLUG, variable);
  mqtt.publish(topic, (const uint8_t*)payload, n, false);
}

float nivelMetros() {
  if (distanciaActual <= 0) return 0;
  float nivel = (DISTANCIA_POZO_VACIO - distanciaActual) / 100.0f;
  return nivel < 0 ? 0 : nivel;
}

void publicarTodo() {
  if (!mqtt.connected()) return;
  publicarVariable("nivel_m", roundf(nivelMetros() * 1000) / 1000.0f);
  publicarVariable("caudal_lpm", roundf(caudalLmin * 10) / 10.0f);
  publicarVariable("volumen_l", (float)(round(volumenTotalL * 10) / 10.0));
  publicarVariable("motor", motorEncendido ? 1 : 0);
  publicarVariable("modo_auto", modo == AUTO ? 1 : 0);
  publicarVariable("falla_seco", fallaPorSeco ? 1 : 0);
  publicarVariable("rssi_dbm", WiFi.RSSI());
  Serial.printf("Telemetría: nivel=%.2fm caudal=%.1fL/min vol=%.1fL motor=%d modo=%s falla=%d\n",
                nivelMetros(), caudalLmin, volumenTotalL, motorEncendido,
                modo == AUTO ? "AUTO" : (modo == MANUAL_ON ? "MANUAL_ON" : "MANUAL_OFF"), fallaPorSeco);
}

void alRecibirComando(char* topic, byte* payload, unsigned int length) {
  StaticJsonDocument<192> doc;
  if (deserializeJson(doc, payload, length)) {
    Serial.println("Comando con JSON inválido, se ignora.");
    return;
  }
  const char* token = doc["token"] | "";
  if (strcmp(token, DEVICE_TOKEN) != 0) {
    Serial.println("Comando con token inválido, se ignora.");
    return;
  }
  float valor = doc["value"] | 0.0f;
  bool on = valor >= 0.5f;

  // topic = <prefijo>/<slug>/<variable>/set -> extrae <variable>
  String t = String(topic);
  int fin = t.lastIndexOf("/set");
  int ini = t.lastIndexOf('/', fin - 1) + 1;
  String variable = t.substring(ini, fin);

  if (variable == "motor") {
    modo = on ? MANUAL_ON : MANUAL_OFF;
  } else if (variable == "modo_auto") {
    if (on) {
      modo = AUTO;
      fallaPorSeco = false;  // rearme tras una falla, igual que el sketch original
    } else {
      modo = motorEncendido ? MANUAL_ON : MANUAL_OFF;
    }
  } else {
    Serial.print("Variable de comando desconocida: ");
    Serial.println(variable);
    return;
  }
  Serial.printf("Comando %s = %.0f\n", variable.c_str(), valor);
  publicarYa = true;
}

void reconectarMQTT() {
  if (mqtt.connected() || WiFi.status() != WL_CONNECTED) return;
  Serial.printf("Conectando a MQTT %s:%d ... ", MQTT_HOST, MQTT_PORT);
  String clientId = String(DEVICE_SLUG) + "-" + String((uint32_t)ESP.getEfuseMac(), HEX);
  if (mqtt.connect(clientId.c_str(), MQTT_USER, MQTT_PASS)) {
    Serial.println("OK");
    mqtt.subscribe(topicComandos, 1);
    publicarYa = true;
  } else {
    Serial.printf("falló rc=%d\n", mqtt.state());
  }
}

// =====================================================================
//  SENSORES Y MOTOR
// =====================================================================
float medirDistanciaCM() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  long duracion = pulseIn(ECHO_PIN, HIGH, 25000);  // ~4 m máx.
  if (duracion == 0) return -1;
  return duracion * 0.0343f / 2.0f;
}

void encenderMotor(const char* motivo) {
  if (motorEncendido) return;
  digitalWrite(RELAY_PIN, RELAY_ON);
  motorEncendido = true;
  tiempoInicioSinFlujo = millis();
  Serial.printf(">> BOMBA ENCENDIDA (%s)\n", motivo);
  publicarYa = true;
}

void apagarMotor(const char* motivo) {
  if (!motorEncendido) return;
  digitalWrite(RELAY_PIN, RELAY_OFF);
  motorEncendido = false;
  Serial.printf(">> BOMBA APAGADA (%s)\n", motivo);
  publicarYa = true;
}

// =====================================================================
//  SETUP / LOOP
// =====================================================================
void setup() {
  Serial.begin(115200);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(RELAY_PIN, OUTPUT);
  pinMode(FLOW_PIN, INPUT_PULLUP);
  digitalWrite(RELAY_PIN, RELAY_OFF);
  attachInterrupt(digitalPinToInterrupt(FLOW_PIN), contarPulso, FALLING);

  prefs.begin("pozo", false);
  volumenTotalL = prefs.getDouble("vol_total", 0);
  volumenGuardado = volumenTotalL;

  conectarWiFi();
  configTime(0, 0, "pool.ntp.org", "time.google.com");  // UTC: la plataforma convierte a hora de Chile

  snprintf(topicComandos, sizeof(topicComandos), "%s/%s/+/set", MQTT_PREFIX, DEVICE_SLUG);
  mqtt.setServer(MQTT_HOST, MQTT_PORT);
  mqtt.setCallback(alRecibirComando);
  mqtt.setBufferSize(512);

  Serial.println("AquaPozo IoT · ESP32 del pozo iniciada.");
}

void loop() {
  unsigned long ahora = millis();

  // --- conexión ---
  if (WiFi.status() != WL_CONNECTED) conectarWiFi();
  static unsigned long ultimoIntentoMqtt = 0;
  if (!mqtt.connected() && ahora - ultimoIntentoMqtt > 5000) {
    ultimoIntentoMqtt = ahora;
    reconectarMQTT();
  }
  mqtt.loop();

  // --- 1. nivel (ultrasonido, cada 1 s) ---
  if (ahora - ultimaLecturaUltrasonico >= 1000) {
    ultimaLecturaUltrasonico = ahora;
    float d = medirDistanciaCM();
    ultrasonicoOk = d > 0;
    if (ultrasonicoOk) distanciaActual = d;
  }

  // --- 2. caudal y volumen (cada 1 s) ---
  if (ahora - ultimoCalculoFlujo >= 1000) {
    noInterrupts();
    unsigned long pulsosAhora = pulsosTotales;
    interrupts();
    unsigned long pulsos = pulsosAhora - pulsosUltimoCiclo;
    pulsosUltimoCiclo = pulsosAhora;
    float segundos = (ahora - ultimoCalculoFlujo) / 1000.0f;
    ultimoCalculoFlujo = ahora;

    caudalLmin = (pulsos / PULSOS_POR_LITRO) * (60.0f / segundos);
    volumenTotalL += pulsos / PULSOS_POR_LITRO;

    // guarda el volumen en flash cada 10 L (no cada segundo: la flash tiene ciclos limitados)
    if (volumenTotalL - volumenGuardado >= 10.0) {
      prefs.putDouble("vol_total", volumenTotalL);
      volumenGuardado = volumenTotalL;
    }

    // --- 3. protección contra marcha en seco ---
    if (motorEncendido) {
      if (caudalLmin < UMBRAL_SIN_FLUJO_LPM) {
        if (ahora - tiempoInicioSinFlujo >= TIEMPO_MAX_SIN_FLUJO_MS) {
          apagarMotor("sin flujo: posible pozo seco");
          fallaPorSeco = true;
        }
      } else {
        tiempoInicioSinFlujo = ahora;
      }
    }
  }

  // --- 4. control de la bomba ---
  if (modo == MANUAL_ON) {
    if (!fallaPorSeco) encenderMotor("modo manual");
  } else if (modo == MANUAL_OFF) {
    apagarMotor("modo manual");
  } else if (ultrasonicoOk && !fallaPorSeco) {
#if LOGICA_POZO
    // pozo: extraer mientras haya agua suficiente, parar antes de dejar la bomba en seco
    if (distanciaActual <= DIST_NIVEL_ALTO) encenderMotor("nivel alto en el pozo");
    else if (distanciaActual >= DIST_NIVEL_BAJO) apagarMotor("nivel bajo en el pozo");
#else
    // estanque: llenar cuando está bajo, parar cuando está lleno
    if (distanciaActual >= DIST_NIVEL_BAJO) encenderMotor("estanque bajo");
    else if (distanciaActual <= DIST_NIVEL_ALTO) apagarMotor("estanque lleno");
#endif
  }

  // --- 5. telemetría ---
  if (publicarYa || ahora - ultimoEnvio >= PUBLICAR_CADA_MS) {
    publicarYa = false;
    ultimoEnvio = ahora;
    publicarTodo();
  }
}
