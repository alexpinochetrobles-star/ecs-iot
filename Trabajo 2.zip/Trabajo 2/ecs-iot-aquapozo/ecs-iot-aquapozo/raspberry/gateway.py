"""AquaPozo IoT · Controlador del tablero en la Raspberry Pi.

Un solo proceso que hace tres trabajos:

1. Tablero (GPIO de la Raspberry):
     - flotador de nivel mínimo (entrada, contacto NC)  -> flotador_min_ok
     - pulsador de paro de emergencia (entrada, NC)     -> paro_emergencia
     - baliza / luz de alarma (salida a relé)           -> baliza  (mandable desde el dashboard)
     - temperatura de la CPU                            -> cpu_temp_c

2. Horómetro de la bomba:
     escucha el estado "motor" que publica la ESP32 y acumula las horas de
     marcha (se guardan en horometro.json, sobreviven a reinicios) -> horometro_h

3. Enclavamiento de seguridad:
     si se presiona el paro de emergencia o el flotador marca nivel mínimo,
     ordena a la ESP32 apagar la bomba (motor/set = 0) y enciende la baliza.

Todo habla el contrato MQTT de la plataforma:
    publica  <prefijo>/<slug>/<variable>      {"value", "timestamp", "token"}
    escucha  <prefijo>/<slug>/<variable>/set  {"value", "token"}

Uso:
    cp config.example.env config.env   # y completar
    python3 gateway.py
    python3 gateway.py --simular-gpio  # en un PC sin GPIO (pruebas)
"""
import argparse
import json
import logging
import os
import random
import threading
import time
from datetime import datetime, timezone

import paho.mqtt.client as mqtt

log = logging.getLogger("gateway")

DEFAULTS = {
    "MQTT_HOST": "127.0.0.1",
    "MQTT_PORT": "1883",
    "MQTT_USER": "",
    "MQTT_PASS": "",
    "MQTT_PREFIX": "ecs",
    "RPI_SLUG": "rpi-tablero-001",
    "RPI_TOKEN": "",
    "ESP32_SLUG": "esp32-pozo-001",
    "ESP32_TOKEN": "",
    "GPIO_FLOTADOR": "17",
    "GPIO_PARO": "22",
    "GPIO_BALIZA": "27",
    "BALIZA_ACTIVA_ALTO": "1",
    "ENCLAVAMIENTO": "1",
    "HOROMETRO_ARCHIVO": "horometro.json",
    "PUBLICAR_CADA_S": "2",
}


def cargar_config(ruta):
    """Lee un archivo CLAVE=valor; las variables de entorno tienen prioridad."""
    cfg = dict(DEFAULTS)
    if os.path.exists(ruta):
        with open(ruta, encoding="utf-8") as fh:
            for linea in fh:
                linea = linea.strip()
                if linea and not linea.startswith("#") and "=" in linea:
                    clave, valor = linea.split("=", 1)
                    cfg[clave.strip()] = valor.strip().strip('"').strip("'")
    for clave in cfg:
        if clave in os.environ:
            cfg[clave] = os.environ[clave]
    return cfg


def ahora_iso():
    return datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# Tablero: GPIO real (gpiozero) o simulado
# ---------------------------------------------------------------------------
class TableroGPIO:
    """Entradas NC con pull-up: contacto cerrado = pin a GND = is_pressed True."""

    def __init__(self, cfg):
        from gpiozero import Button, DigitalOutputDevice

        self._flotador = Button(int(cfg["GPIO_FLOTADOR"]), pull_up=True, bounce_time=0.05)
        self._paro = Button(int(cfg["GPIO_PARO"]), pull_up=True, bounce_time=0.05)
        self._baliza = DigitalOutputDevice(
            int(cfg["GPIO_BALIZA"]), active_high=cfg["BALIZA_ACTIVA_ALTO"] == "1", initial_value=False
        )

    def flotador_ok(self):
        return self._flotador.is_pressed      # flotador NC cerrado = nivel sobre el mínimo

    def paro_activo(self):
        return not self._paro.is_pressed      # pulsador NC: si se abre (o se corta el cable) = paro

    def baliza(self, encendida=None):
        if encendida is not None:
            self._baliza.value = 1 if encendida else 0
        return bool(self._baliza.value)


class TableroSimulado:
    """Para probar en un PC. Las entradas se pueden forzar editando sim_gpio.json:
    {"flotador_min_ok": 1, "paro_emergencia": 0}"""

    ARCHIVO = "sim_gpio.json"

    def __init__(self, _cfg):
        self._baliza = False

    def _leer(self):
        try:
            with open(self.ARCHIVO, encoding="utf-8") as fh:
                return json.load(fh)
        except (OSError, ValueError):
            return {}

    def flotador_ok(self):
        return bool(self._leer().get("flotador_min_ok", 1))

    def paro_activo(self):
        return bool(self._leer().get("paro_emergencia", 0))

    def baliza(self, encendida=None):
        if encendida is not None:
            self._baliza = bool(encendida)
        return self._baliza


def temperatura_cpu():
    try:
        with open("/sys/class/thermal/thermal_zone0/temp", encoding="utf-8") as fh:
            return round(int(fh.read().strip()) / 1000.0, 1)
    except (OSError, ValueError):
        return round(45 + random.uniform(-1, 1), 1)  # PC de pruebas sin sensor


# ---------------------------------------------------------------------------
# Horómetro de la bomba (horas de marcha acumuladas, persistentes)
# ---------------------------------------------------------------------------
class Horometro:
    def __init__(self, archivo):
        self.archivo = archivo
        self.lock = threading.Lock()
        self.segundos = 0.0
        self.desde = None          # instante en que arrancó la bomba (None = detenida)
        self._ultimo_guardado = time.time()
        try:
            with open(archivo, encoding="utf-8") as fh:
                self.segundos = float(json.load(fh).get("segundos", 0))
        except (OSError, ValueError):
            pass

    def motor(self, en_marcha):
        with self.lock:
            ahora = time.time()
            if en_marcha and self.desde is None:
                self.desde = ahora
            elif not en_marcha and self.desde is not None:
                self.segundos += ahora - self.desde
                self.desde = None
                self._guardar()

    def horas(self):
        with self.lock:
            total = self.segundos + (time.time() - self.desde if self.desde else 0)
            if time.time() - self._ultimo_guardado > 60:
                self._guardar(total)
            return round(total / 3600.0, 3)

    def _guardar(self, total=None):
        self._ultimo_guardado = time.time()
        try:
            with open(self.archivo, "w", encoding="utf-8") as fh:
                json.dump({"segundos": total if total is not None else self.segundos}, fh)
        except OSError as exc:
            log.warning("No se pudo guardar el horómetro: %s", exc)


# ---------------------------------------------------------------------------
# Controlador del tablero
# ---------------------------------------------------------------------------
class Gateway:
    def __init__(self, cfg, simular_gpio):
        self.cfg = cfg
        self.prefijo = cfg["MQTT_PREFIX"]
        self.tablero = TableroSimulado(cfg) if simular_gpio else TableroGPIO(cfg)
        self.horometro = Horometro(cfg["HOROMETRO_ARCHIVO"])
        self.baliza_manual = False
        self.motor_esp32 = None
        self.ultimo_enclavamiento = 0.0

        self.mqtt = mqtt.Client(client_id=f"gateway-{cfg['RPI_SLUG']}-{random.randint(1000, 9999)}")
        if cfg["MQTT_USER"]:
            self.mqtt.username_pw_set(cfg["MQTT_USER"], cfg["MQTT_PASS"])
        self.mqtt.on_connect = self._on_connect
        self.mqtt.on_message = self._on_message
        self.mqtt.reconnect_delay_set(1, 30)

    # --- MQTT ---
    def _topic(self, slug, variable):
        return f"{self.prefijo}/{slug}/{variable}"

    def publicar(self, variable, valor):
        payload = {"value": valor, "timestamp": ahora_iso(), "token": self.cfg["RPI_TOKEN"]}
        self.mqtt.publish(self._topic(self.cfg["RPI_SLUG"], variable), json.dumps(payload), qos=1)

    def _on_connect(self, client, _u, _f, rc):
        if rc != 0:
            log.error("MQTT rechazó la conexión (rc=%s): revisa usuario/clave", rc)
            return
        log.info("Conectado al broker %s:%s", self.cfg["MQTT_HOST"], self.cfg["MQTT_PORT"])
        client.subscribe(self._topic(self.cfg["RPI_SLUG"], "+/set"), qos=1)
        client.subscribe(self._topic(self.cfg["ESP32_SLUG"], "motor"), qos=1)  # horómetro y enclavamiento

    def _on_message(self, _client, _u, msg):
        partes = msg.topic.split("/")
        try:
            data = json.loads(msg.payload)
            valor = float(data["value"])
        except (ValueError, KeyError, TypeError):
            return

        # estado de la bomba que publica la ESP32
        if len(partes) == 3 and partes[1] == self.cfg["ESP32_SLUG"] and partes[2] == "motor":
            if data.get("token") != self.cfg["ESP32_TOKEN"]:
                return
            self.motor_esp32 = valor >= 0.5
            self.horometro.motor(self.motor_esp32)
            return

        # comandos del dashboard para la Raspberry
        if len(partes) != 4 or partes[1] != self.cfg["RPI_SLUG"] or partes[3] != "set":
            return
        if data.get("token") != self.cfg["RPI_TOKEN"]:
            log.warning("Comando con token inválido en %s", msg.topic)
            return
        if partes[2] == "baliza":
            self.baliza_manual = valor >= 0.5
            log.info("Baliza manual -> %s", "ON" if self.baliza_manual else "OFF")
            self.ciclo()

    # --- ciclo principal ---
    def ciclo(self):
        flotador_ok = self.tablero.flotador_ok()
        paro = self.tablero.paro_activo()
        alarma = paro or not flotador_ok
        baliza = self.tablero.baliza(self.baliza_manual or alarma)

        if alarma and self.cfg["ENCLAVAMIENTO"] == "1":
            self.enclavar("paro de emergencia" if paro else "nivel mínimo (flotador)")

        self.publicar("flotador_min_ok", int(flotador_ok))
        self.publicar("paro_emergencia", int(paro))
        self.publicar("baliza", int(baliza))
        self.publicar("horometro_h", self.horometro.horas())
        self.publicar("cpu_temp_c", temperatura_cpu())

    def enclavar(self, motivo):
        """Ordena a la ESP32 detener la bomba (máx. una vez cada 3 s mientras siga en marcha)."""
        if self.motor_esp32 is False:
            return
        if time.time() - self.ultimo_enclavamiento < 3:
            return
        self.ultimo_enclavamiento = time.time()
        if not self.cfg["ESP32_TOKEN"]:
            log.warning("Enclavamiento por %s, pero falta ESP32_TOKEN en config.env", motivo)
            return
        payload = {"value": 0, "token": self.cfg["ESP32_TOKEN"]}
        self.mqtt.publish(self._topic(self.cfg["ESP32_SLUG"], "motor/set"), json.dumps(payload), qos=1)
        log.warning("ENCLAVAMIENTO: %s -> bomba detenida", motivo)

    def correr(self):
        for clave in ("RPI_TOKEN", "ESP32_TOKEN"):
            if not self.cfg[clave]:
                log.warning("Falta %s en config.env", clave)
        self.mqtt.connect_async(self.cfg["MQTT_HOST"], int(self.cfg["MQTT_PORT"]), 60)
        self.mqtt.loop_start()
        intervalo = float(self.cfg["PUBLICAR_CADA_S"])
        try:
            while True:
                inicio = time.time()
                if self.mqtt.is_connected():
                    self.ciclo()
                time.sleep(max(0.2, intervalo - (time.time() - inicio)))
        except KeyboardInterrupt:
            pass
        finally:
            self.horometro.motor(False)
            self.tablero.baliza(False)
            self.mqtt.loop_stop()
            self.mqtt.disconnect()


def main():
    parser = argparse.ArgumentParser(description="Controlador del tablero (Raspberry Pi) -> MQTT")
    parser.add_argument("--config", default="config.env")
    parser.add_argument("--simular-gpio", action="store_true", help="no usa GPIO (para probar en un PC)")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    Gateway(cargar_config(args.config), args.simular_gpio).correr()


if __name__ == "__main__":
    main()
