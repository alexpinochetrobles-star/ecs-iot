"""Simulador del pozo profundo (AquaPozo IoT).

Reemplaza a los equipos reales cuando no están conectados, para probar la
plataforma o tener respaldo en la demo. Simula un pozo con recarga natural y
una bomba sumergible, y responde a los comandos del dashboard igual que el
hardware real:

  - ESP32  : nivel_m, caudal_lpm, volumen_l, motor, modo_auto, falla_seco, rssi_dbm
  - RPi    : flotador_min_ok, paro_emergencia, baliza, horometro_h, cpu_temp_c

SIM_EQUIPOS elige cuáles simular (ej. "rpi" si ya tienes la ESP32 real).
Contrato MQTT: <prefijo>/<slug>/<variable> {"value", "timestamp", "token"} y
comandos en <prefijo>/<slug>/<variable>/set {"value", "token"}.
"""
import json
import os
import random
import time
from datetime import datetime, timezone

import paho.mqtt.client as mqtt

HOST = os.environ.get("MQTT_BROKER_HOST", "mosquitto")
PORT = int(os.environ.get("MQTT_BROKER_PORT", "1883"))
USER = os.environ.get("MQTT_USERNAME", "")
PASSWORD = os.environ.get("MQTT_PASSWORD", "")
PREFIX = os.environ.get("MQTT_TOPIC_PREFIX", "ecs")
INTERVAL = float(os.environ.get("SIMULATOR_INTERVAL_SECONDS", "2"))
EQUIPOS = {e.strip() for e in os.environ.get("SIM_EQUIPOS", "esp32,rpi").split(",") if e.strip()}

SLUG = {
    "esp32": os.environ.get("POZO_ESP32_SLUG", "esp32-pozo-001"),
    "rpi": os.environ.get("POZO_RPI_SLUG", "rpi-tablero-001"),
}
TOKEN = {
    "esp32": os.environ.get("POZO_TOKEN_ESP32", ""),
    "rpi": os.environ.get("POZO_TOKEN_RPI", ""),
}

# --- parámetros físicos (ajustados para que un ciclo dure ~3 minutos en la demo) ---
NIVEL_MAX = 1.2          # m de columna de agua visible por el sensor
NIVEL_ENCENDER = 1.0     # lógica de pozo: arranca con nivel alto...
NIVEL_APAGAR = 0.25      # ...y para antes de dejar la bomba en seco
RECARGA_M_S = 0.006      # recarga natural del acuífero
BOMBEO_M_S = 0.020       # descenso por bombeo
CAUDAL_NOMINAL = 18.0    # L/min con válvula abierta
SIN_FLUJO_S = 10         # igual que el firmware: 10 s sin caudal => falla marcha en seco


class Pozo:
    def __init__(self):
        self.nivel = 0.8
        self.modo = "AUTO"            # AUTO | MANUAL_ON | MANUAL_OFF
        self.motor = False
        self.falla_seco = False
        self.sin_flujo_desde = None
        self.caudal = 0.0
        self.volumen = 15230.0
        self.baliza = False
        self.paro = False
        self.horometro = 1250.0
        self.cpu = 48.0

    @property
    def flotador_ok(self):
        return self.nivel > 0.12

    def step(self, dt):
        bloqueo = self.paro or not self.flotador_ok

        # lógica de control (la misma del firmware de la ESP32)
        if bloqueo:
            self.motor = False
        elif self.modo == "MANUAL_ON":
            if not self.falla_seco:
                self.motor = True
        elif self.modo == "MANUAL_OFF":
            self.motor = False
        elif not self.falla_seco:
            if self.nivel >= NIVEL_ENCENDER:
                self.motor = True
            elif self.nivel <= NIVEL_APAGAR:
                self.motor = False

        # hidráulica
        hay_agua = self.nivel > 0.05
        if self.motor and hay_agua:
            self.caudal = CAUDAL_NOMINAL * random.uniform(0.95, 1.05) * min(1.0, self.nivel / 0.3)
        else:
            self.caudal = 0.0
        bajada = BOMBEO_M_S if (self.motor and self.caudal > 0) else 0.0
        self.nivel = max(0.0, min(NIVEL_MAX, self.nivel + (RECARGA_M_S - bajada) * dt))
        self.volumen += self.caudal / 60.0 * dt

        # protección contra marcha en seco
        if self.motor and self.caudal < 0.5:
            self.sin_flujo_desde = self.sin_flujo_desde or time.time()
            if time.time() - self.sin_flujo_desde >= SIN_FLUJO_S:
                self.motor = False
                self.falla_seco = True
        else:
            self.sin_flujo_desde = None

        if self.motor:
            self.horometro += dt / 3600.0
        self.cpu += random.uniform(-0.4, 0.4)
        self.cpu = max(42.0, min(62.0, self.cpu))

    def lecturas(self):
        alarma = self.falla_seco or self.paro or not self.flotador_ok
        return {
            "esp32": {
                "nivel_m": round(self.nivel, 3),
                "caudal_lpm": round(self.caudal, 1),
                "volumen_l": round(self.volumen, 1),
                "motor": int(self.motor),
                "modo_auto": int(self.modo == "AUTO"),
                "falla_seco": int(self.falla_seco),
                "rssi_dbm": random.randint(-68, -55),
            },
            "rpi": {
                "flotador_min_ok": int(self.flotador_ok),
                "paro_emergencia": int(self.paro),
                "baliza": int(self.baliza or alarma),
                "horometro_h": round(self.horometro, 2),
                "cpu_temp_c": round(self.cpu, 1),
            },
        }

    def comando(self, equipo, variable, value):
        on = value >= 0.5
        if equipo == "esp32" and variable == "motor":
            self.modo = "MANUAL_ON" if on else "MANUAL_OFF"
        elif equipo == "esp32" and variable == "modo_auto":
            if on:
                self.modo = "AUTO"
                self.falla_seco = False  # rearme, igual que el firmware
            else:
                self.modo = "MANUAL_ON" if self.motor else "MANUAL_OFF"
        elif equipo == "rpi" and variable == "baliza":
            self.baliza = on
        elif equipo == "rpi" and variable == "paro_emergencia":
            self.paro = on  # solo en el simulador: permite probar el paro desde MQTT
        else:
            return False
        return True


def main():
    pozo = Pozo()
    equipo_por_slug = {SLUG[e]: e for e in EQUIPOS}

    client = mqtt.Client(client_id=f"simulador-pozo-{random.randint(1000, 9999)}")
    if USER:
        client.username_pw_set(USER, PASSWORD)

    def publicar(equipo, variable, value):
        payload = {
            "value": value,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "token": TOKEN[equipo],
        }
        client.publish(f"{PREFIX}/{SLUG[equipo]}/{variable}", json.dumps(payload), qos=1)

    def on_connect(c, userdata, flags, rc):
        print(f"Conectado al broker {HOST}:{PORT} (rc={rc}). Simulando: {', '.join(sorted(EQUIPOS))}", flush=True)
        for equipo in EQUIPOS:
            c.subscribe(f"{PREFIX}/{SLUG[equipo]}/+/set", qos=1)

    def on_message(c, userdata, msg):
        parts = msg.topic.split("/")
        if len(parts) != 4:
            return
        equipo = equipo_por_slug.get(parts[1])
        if equipo is None:
            return
        try:
            data = json.loads(msg.payload)
            value = float(data["value"])
        except (ValueError, KeyError, TypeError):
            return
        if data.get("token") != TOKEN[equipo]:
            print(f"Comando con token inválido en {msg.topic}, ignorado.", flush=True)
            return
        if pozo.comando(equipo, parts[2], value):
            print(f"Comando {equipo}/{parts[2]} = {value}", flush=True)
            pozo.step(0)  # aplica el comando ya, sin esperar el próximo ciclo
            for var, val in pozo.lecturas()[equipo].items():  # confirma el nuevo estado
                publicar(equipo, var, val)

    client.on_connect = on_connect
    client.on_message = on_message
    client.reconnect_delay_set(1, 30)
    client.connect(HOST, PORT, keepalive=60)
    client.loop_start()

    for equipo in EQUIPOS:
        if not TOKEN[equipo]:
            print(f"AVISO: falta POZO_TOKEN_{equipo.upper()}; el listener rechazará sus lecturas.", flush=True)

    try:
        while True:
            pozo.step(INTERVAL)
            for equipo, variables in pozo.lecturas().items():
                if equipo in EQUIPOS:
                    for variable, value in variables.items():
                        publicar(equipo, variable, value)
            time.sleep(INTERVAL)
    except KeyboardInterrupt:
        pass
    finally:
        client.loop_stop()
        client.disconnect()


if __name__ == "__main__":
    main()
